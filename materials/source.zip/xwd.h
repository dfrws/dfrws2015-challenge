// function prototypes for visible xwd.c functions
void screenshot(unsigned char *buffer, unsigned *bufsize);
